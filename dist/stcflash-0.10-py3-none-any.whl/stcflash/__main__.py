import sys
import stcflash.frontend

if __name__ == "__main__":
    sys.exit(stcflash.frontend.cli())
